export default {
  httpBody: null
}

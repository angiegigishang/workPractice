export default
[
  { path: '/', component: () => import('components/index') },

  // Always leave this last one
  { path: '*', component: () => import('components/Error404') } // Not found
]

export default {
  message: {
    confirmation: '确认执行此次操作？',
    noData: '暂无数据',
    pageLable: '每页显示行数: '
  },
  button: {
    confirm: '确认',
    cancel: '取消'
  }
}

export const updateHttpBody = (state, data) => {
  if (data) {
    state.httpBody = data
  }
}

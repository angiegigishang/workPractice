<template>
  <q-layout view="HHH lpr fff">
    <q-layout-header>
      <mg-toolbar title="User App"></mg-toolbar>
    </q-layout-header>

    <q-page-container>
      <div class="content text-center">{{ msg }}</div>
    </q-page-container>
  </q-layout>
</template>

<script>

export default {
  data () {
    return {
      msg: 'Hello, User App'
    }
  }
}
</script>

<style lang="stylus" scoped>
  @import '~variables'

  .content
    margin-top 100px
    font-size 24px
    color $tertiary
</style>

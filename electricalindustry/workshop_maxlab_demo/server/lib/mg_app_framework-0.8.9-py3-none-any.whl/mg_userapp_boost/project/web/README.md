# Quasar App

> A Quasar project

## Build Setup

``` bash
# install dependencies
$ npm install

# serve with hot reload at localhost:8080
$ npm run app_dev

# build for production with minification
$ npm run app_build

# lint code
$ quasar lint

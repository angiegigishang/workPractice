from mg_app_name.handlers.websocket_handler.handler import WebHandler

url = [
    (r'/websocket_url', WebHandler),
]

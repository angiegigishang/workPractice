from mg_app_name.handlers.http_handler.handler import WebHandler

url = [
    (r'/http_url', WebHandler),
]

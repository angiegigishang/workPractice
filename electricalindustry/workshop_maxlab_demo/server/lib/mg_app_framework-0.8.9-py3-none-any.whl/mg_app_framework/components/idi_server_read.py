import datetime
import time
from tornado import gen
from mg_app_framework.config import Store, get_logger, set_handler, get_handler
from mg_app_framework.components import TaskKey
from mg_app_framework.process import start_next_task
from mg_app_framework.message import MesCode
from abc import ABCMeta, abstractmethod
from tornado.gen import multi


class IdiServerReadConfigBasic(metaclass=ABCMeta):
    @abstractmethod
    def get_mongodb_host(self):
        pass

    @abstractmethod
    def get_mongodb_port(self):
        pass

    def retry_interval(self):
        return 5


class MongodbConnectError(Exception):
    def __init__(self):
        Store.get_loop().stop()


async def idi_server_read_connect(re_conn=True, conn_time=None):
    import motor
    __cnt = 0
    while True:
        try:
            if conn_time and __cnt == int(conn_time):
                get_logger().error(
                    'Idi server read mongodb async connect error,connect more than ' + str(conn_time) + ' times')
                raise MongodbConnectError
            store = Store.get_init_task_config(TaskKey.idi_server_read)
            mongodb_host = store.get_mongodb_host()
            mongodb_port = int(store.get_mongodb_port())
            connector = motor.motor_tornado.MotorClient(mongodb_host, mongodb_port)
            get_logger().info('Idi server read mongodb async connected successfully')
            set_handler(TaskKey.idi_server_read, connector)
            if not re_conn:
                start_next_task(TaskKey.idi_server_read)
                break
            else:
                return connector
        except Exception:
            __cnt += 1
            get_logger().exception('Idi server read mongodb async connecting retry number: ' + str(__cnt))
            store = Store.get_init_task_config(TaskKey.idi_server_read)
            await gen.sleep(store.retry_interval())


async def GetlastestHistoryDatasByCodes(organization_codelist):
    #organization_codelist = = {factory1: [{"code": code1, "start_time": start_time, "end_time": end_time},
                    #{"code": code2, "start_time": start_time, "end_time": end_time}]}
    get_logger().info('get lastest datas time : %s.',
                      str(time.strftime("%Y-%m-%d %H:%M:%S", time.localtime(time.time()))))
    get_logger().info('get lastest datas params: %s.', str(organization_codelist))
    datas = {}
    request_data = []
    for organization_name, codelist in organization_codelist.items():
        datas.update({organization_name: {}})
        if not codelist:
            return MesCode.fail
        for params in codelist:
            if not params:
                get_logger().error('参数为空')
                return MesCode.fail
            code_name = params['code']
            if not code_name:
                get_logger().error('编码名为空')
                return MesCode.fail

            start_time = params.get('start_time')
            end_time = params.get('end_time')

            if '24:00:00' in start_time or '24:00:00' in end_time:
                get_logger().error('时间不能为24:00:00,请改为00:00:00')
                return MesCode.fail

            if start_time != end_time:
                get_logger().error('起始时间不等于结束时间')
                return MesCode.fail

            datas.get(organization_name).update({code_name: {}})
            request_data.append({
                "organization_name": organization_name,
                "code_name": code_name,
                "start_time": start_time,
            })

    async def get_data(organization_name, code_name, start_time):
        try:
            data = {}
            handle = get_handler(TaskKey.idi_server_read)
            db_name = 'idi_' + organization_name
            query_db = handle[db_name]
            collection = query_db.get_collection('datas')
            time_now = time.strftime("%Y-%m-%d %H:%M:%S", time.localtime(time.time()))
            documents = []
            if start_time == '':
                async for document in collection.find({'code': code_name,
                                                       'timestamp': {'$lte': datetime.datetime.strptime(time_now,
                                                                                                        "%Y-%m-%d %H:%M:%S")}}).sort(
                    [("timestamp", -1)]).limit(7):
                    if document not in documents:
                        documents.append(document)

            else:
                async for document in collection.find({'code': code_name,
                                                       'timestamp': {'$lte': datetime.datetime.strptime(start_time,
                                                                                                        "%Y-%m-%d %H:%M:%S")}}).sort(
                    [("timestamp", -1)]).limit(4):
                    if document not in documents:
                        documents.append(document)

                async for document in collection.find(
                        {'code': code_name, 'timestamp': {'$gte': datetime.datetime.strptime(start_time,
                                                                                             "%Y-%m-%d %H:%M:%S")}}).sort(
                    [("timestamp", 1)]).limit(4):
                    if document not in documents:
                        documents.append(document)

            documents = sorted(documents, key=lambda x: x['timestamp'])
            for document in documents:
                ts = document['timestamp'].strftime("%Y-%m-%d %H:%M:%S")
                value = document['value']
                data.update({ts: value})

            datas.get(organization_name)[code_name] = data
        except Exception as e:
            get_logger().exception(e)

    if request_data:
        await multi(get_data(i["organization_name"], i["code_name"], i["start_time"]) for i in request_data)
    get_logger().info('response lastest datas time : %s.',
                      str(time.strftime("%Y-%m-%d %H:%M:%S", time.localtime(time.time()))))
    return datas


async def GetHistoryDatasByCodes(organization_codelist):
    #codelist = = {factory1: [{"code": code1, "start_time": start_time, "end_time": end_time},
                    #{"code": code2, "start_time": start_time, "end_time": end_time}]}
    get_logger().info('get history datas time : %s.',
                      str(time.strftime("%Y-%m-%d %H:%M:%S", time.localtime(time.time()))))
    get_logger().info('get history datas params: %s.', str(organization_codelist))
    datas = {}
    request_data = []

    for organization_name, codelist in organization_codelist.items():
        datas.update({organization_name: {}})
        if not codelist:
            return MesCode.fail
        for params in codelist:
            if not params:
                get_logger().error('参数为空')
                return MesCode.fail

            code_name = params['code']
            if not code_name:
                get_logger().error('编码名为空')
                return MesCode.fail

            start_time = params.get('start_time')
            end_time = params.get('end_time')

            start_date = None
            if not start_time:
                get_logger().error('开始时间为空')
                return MesCode.fail
            else:
                if '24:00:00' in start_time:
                    get_logger().error('时间不能为24:00:00,请改为00:00:00')
                    return MesCode.fail
                else:
                    try:
                        start_date = datetime.datetime.strptime(start_time.split(' ')[0], '%Y-%m-%d').timestamp()
                    except Exception as e:
                        get_logger().error('开始时间格式错误')
                        return MesCode.fail
            if not end_time:
                end_time = datetime.datetime.now().strftime("%Y-%m-%d %H:%M:%S")
                end_date = time.mktime(datetime.date.today().timetuple())
            else:
                if '24:00:00' in end_time:
                    get_logger().error('时间不能为24:00:00,请改为00:00:00')
                    return MesCode.fail
                else:
                    try:
                        end_date = datetime.datetime.strptime(end_time.split(' ')[0], '%Y-%m-%d').timestamp()
                    except Exception as e:
                        get_logger().error('结束时间格式错误')
                        return MesCode.fail

            datas.get(organization_name).update({code_name: {}})
            request_data.append({
                "organization_name": organization_name,
                "code_name": code_name,
                "start_time": start_time,
                "end_time": end_time
            })

    async def get_data(organization_name,code_name, start_time=None, end_time=None):
        try:
            data = {}
            handle = get_handler(TaskKey.idi_server_read)
            db_name = 'idi_' + organization_name
            query_db = handle[db_name]
            collection = query_db.get_collection('datas')
            documents = collection.find(
                {'code': code_name, 'timestamp': {'$gte': datetime.datetime.strptime(start_time, "%Y-%m-%d %H:%M:%S"),
                                                  '$lte': datetime.datetime.strptime(end_time,
                                                                                     "%Y-%m-%d %H:%M:%S")}}).sort(
                [("timestamp", 1)])
            async for document in documents:
                ts = document['timestamp'].strftime("%Y-%m-%d %H:%M:%S")
                value = document['value']
                data.update({ts: value})
            datas.get(organization_name)[code_name] = data
        except Exception as e:
            get_logger().exception(e)

    if request_data:
        await multi(get_data(i["organization_name"],i["code_name"], i["start_time"], i["end_time"]) for i in request_data)
    get_logger().info('response history datas time : %s.',
                      str(time.strftime("%Y-%m-%d %H:%M:%S", time.localtime(time.time()))))
    return datas

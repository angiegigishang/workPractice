from mg_app_framework.config import Store, get_uuid
from mg_app_framework.client import HttpClient
from mg_app_framework.message import MesCode
import json


def loginrequired(method):
    async def warpper(self, *args, **kwargs):
        login_uuid = self.get_cookie('login_uuid')
        result = dict()
        result['app_group'] = Store.get_app_group()
        result['app_name'] = Store.get_app_name()
        login_url = Store.get_login_url()

        if login_uuid:
            client = HttpClient()
            app_uuid = get_uuid()
            if app_uuid:
                login_role_check_url = login_url + '/check_login_role'
                post_data = {
                    'login_uuid': str(login_uuid),
                    'app_uuid': str(app_uuid)
                }
                res = await client.post(login_role_check_url, data=post_data)
                res_code = res.code
                res_mes = res.info
                if res_code == MesCode.success:
                    return await method(self, *args, **kwargs)
                else:
                    result["code"] = res_code
                    result["info"] = res_mes
                    result["data"] = None
                    if res_code == MesCode.login:
                        result["data"] = {
                            'login_url': login_url,
                            'app_id': app_uuid
                        }
                    self.finish(json.dumps(result, ensure_ascii=False))
                    return
            else:
                result["code"] = MesCode.fail
                result["data"] = None
                result["info"] = '无法获取appid 异常'
                self.finish(json.dumps(result, ensure_ascii=False))
                return

        else:
            result["code"] = MesCode.login
            result["data"] = {
                'login_url': login_url,
                'app_id': get_uuid()
            }
            result["info"] = '登录超时，请重新登录'
            self.finish(json.dumps(result, ensure_ascii=False))
            return

    return warpper


def decimal_format(num, digit=None):
    if digit is None:
        if isinstance(num, list):
            result = []
            for i in num:
                i = float(i)
                if i < 1:
                    i_result = '%.4f' % i
                elif 1 <= i < 1000:
                    i_result = '%.2f' % i
                else:
                    i_result = str(int(i))
                result.append(i_result)
        else:
            num = float(num)
            if num < 1:
                result = '%.4f' % num
            elif 1 <= num < 1000:
                result = '%.2f' % num
            else:
                result = str(int(num))
    else:
        if digit > 0:
            rule = '%.' + str(digit) + 'f'
            if isinstance(num, list):
                result = []
                for i in num:
                    i_result = rule % i
                    result.append(i_result)
            else:
                result = rule % num
        else:
            if isinstance(num, list):
                result = []
                for i in num:
                    i_result = str(int(i))
                    result.append(i_result)
            else:
                result = str(int(num))
    return result


def cron_format(cron_unit):
    return_cron_format = {
            "year": "*",
            "month": "*",
            "day": "*",
            "day_of_week": "*",
            "hour": "*",
            "minute": "*",
            "second": "*",
        }
    if cron_unit == '小时':
        return_cron_format['minute'] = '0'
        return_cron_format['second'] = '0'
    elif cron_unit == '两小时':
        return_cron_format['hour'] = '0,2,4,6,8,10,12,14,16,18,20,22'
        return_cron_format['minute'] = '0'
        return_cron_format['second'] = '0'
    elif cron_unit == '四小时':
        return_cron_format['hour'] = '0,4,8,12,16,20'
        return_cron_format['minute'] = '0'
        return_cron_format['second'] = '0'
    elif cron_unit == '八小时':
        return_cron_format['hour'] = '0,8,16'
        return_cron_format['minute'] = '0'
        return_cron_format['second'] = '0'
    elif cron_unit == '半天':
        return_cron_format['hour'] = '0,12'
        return_cron_format['minute'] = '0'
        return_cron_format['second'] = '0'
    elif cron_unit == '天':
        return_cron_format['hour'] = '0'
        return_cron_format['minute'] = '0'
        return_cron_format['second'] = '0'
    elif cron_unit == '周':
        return_cron_format['day_of_week'] = '0'
        return_cron_format['hour'] = '0'
        return_cron_format['minute'] = '0'
        return_cron_format['second'] = '0'
    elif cron_unit == '月':
        return_cron_format['day'] = '1'
        return_cron_format['hour'] = '0'
        return_cron_format['minute'] = '0'
        return_cron_format['second'] = '0'
    elif cron_unit == '年':
        return_cron_format['month'] = '1'
        return_cron_format['day'] = '1'
        return_cron_format['hour'] = '0'
        return_cron_format['minute'] = '0'
        return_cron_format['second'] = '0'
    elif cron_unit == '分钟':
        return_cron_format['second'] = '0'
    elif cron_unit == '白班':
        return_cron_format['hour'] = '8,16'
        return_cron_format['minute'] = '0'
        return_cron_format['second'] = '0'

    return return_cron_format

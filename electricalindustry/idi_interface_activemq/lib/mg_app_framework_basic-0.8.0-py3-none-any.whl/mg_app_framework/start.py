from tornado.ioloop import IOLoop
import tornado.autoreload

from mg_app_framework.config import Store
from mg_app_framework.components import TaskKey, TASKS


def app_start(debug=True):
    admin_task = TASKS[TaskKey.admin]

    loop = IOLoop.current()
    Store.set_loop(loop)
    Store.set_tasks(TASKS)

    loop.spawn_callback(admin_task, re_conn=False, conn_time=3)

    if debug:
        tornado.autoreload.start()

    loop.start()

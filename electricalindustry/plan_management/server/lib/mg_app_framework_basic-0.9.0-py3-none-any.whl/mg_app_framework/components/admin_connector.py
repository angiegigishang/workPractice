from tornado import websocket, gen
import json
from mg_app_framework.config import Store, set_handler, get_logger, update_context
from mg_app_framework.message import MesType, send_mes
from mg_app_framework.components import TaskKey
from mg_app_framework.process import start_next_task


class AdminConnectError(Exception):
    def __init__(self):
        Store.get_loop().stop()


class UuidNotRegisterError(Exception):
    pass


class UuidRepeatError(Exception):
    pass


# connect to the mg_manager
async def admin_connect(re_conn=True, conn_time=None, debug=False):
    connect_mark = True
    if debug:
        connect_admin = Store.store.connect_admin()
        if not connect_admin:
            connect_mark = False
    if connect_mark:
        __cnt = 0
        while True:
            try:
                if conn_time and __cnt == int(conn_time):
                    get_logger().error('Admin connect error,connect more than ' + str(conn_time) + ' times')
                    raise AdminConnectError
                websocket_url = Store.get_websocket_url()
                admin_handler = await websocket.websocket_connect(websocket_url, ping_interval=30)
                await send_mes(admin_handler, MesType.init_config, Store.get_data())
                message_str = await admin_handler.read_message()
                message = json.loads(message_str)
                if message['type'] == MesType.init_config:
                    if 'app_uuid_register_check' in message['data'] and not message['data']['app_uuid_register_check']:
                        get_logger().error('app_uuid not register')
                        raise UuidNotRegisterError
                    if 'app_uuid_check' in message['data'] and not message['data']['app_uuid_check']:
                        get_logger().error('app_uuid repeat')
                        raise UuidRepeatError
                    if 'name_check' in message['data'] and not message['data']['name_check']:
                        get_logger().warning('app_name repeat')
                    if 'organization' in message['data']:
                        update_context('organization', message['data']['organization'])

                get_logger().info('admin connected successfully')
                set_handler(TaskKey.admin, admin_handler)
                if not re_conn:
                    start_next_task(TaskKey.admin)
                    break
                else:
                    return admin_handler
            except Exception:
                __cnt += 1
                get_logger().exception('admin connecting retry number: ' + str(__cnt))
                await gen.sleep(30)
    else:
        start_next_task(TaskKey.admin)

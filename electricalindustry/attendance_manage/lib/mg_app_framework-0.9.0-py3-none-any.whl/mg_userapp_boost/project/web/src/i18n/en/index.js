export default {
  message: {
    confirmation: 'Are you sure about the operation?',
    noData: 'No Data',
    pageLable: 'rows per page: '
  },
  button: {
    confirm: 'confirm',
    cancel: 'cancel'
  }
}

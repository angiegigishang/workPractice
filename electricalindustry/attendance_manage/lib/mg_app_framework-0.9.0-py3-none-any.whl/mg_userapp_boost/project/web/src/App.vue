<template>
  <div id="q-app">
    <router-view />
  </div>
</template>

# ManuGence Frontend Framework

# install
```
npm install -S git+ssh://git@gitlab.wh.zjrealtech.com:dev/mg-front-end-framework.git
```

# example

### import directly
```
import { MgToolbar } from 'mg-front-end-framework'
```

### register as Vue Component
```
import xxx from 'mg-front-end-framework'
Vue.use(xxx)
```
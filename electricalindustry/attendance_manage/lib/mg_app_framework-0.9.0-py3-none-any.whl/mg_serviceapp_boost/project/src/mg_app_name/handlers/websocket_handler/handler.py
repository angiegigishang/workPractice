from mg_app_framework import WebsocketBasicHandler


class WebHandler(WebsocketBasicHandler):
    def open(self):
        pass

    def on_message(self, message):
        pass

    def on_close(self):
        pass

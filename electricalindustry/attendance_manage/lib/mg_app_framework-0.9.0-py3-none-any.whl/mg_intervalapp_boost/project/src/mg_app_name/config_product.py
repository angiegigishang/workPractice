from os.path import dirname, realpath, basename, join
from mg_app_framework import AppType, AppConfigBasic


class ConfigStore(AppConfigBasic):
    # ==================== DON'T MODIFY THE CODE BETWEEN COMMENT LINE ====================

    work_dir = dirname(dirname(dirname(realpath(__file__))))
    app = basename(dirname(realpath(__file__)))
    log_path = join(work_dir, 'log', app + '.log')
    uuid_path = join(work_dir, '.appid')

    def get_module_dir(self):
        return dirname(realpath(__file__))

    def get_log_path(self):
        return self.log_path

    def get_uuid_path(self):
        return self.uuid_path

    def get_data(self):
        return self.data

    # ==================== DON'T MODIFY THE CODE BETWEEN COMMENT LINE ====================

    data = {
        'app_group': '',
        'app_name': '',
        'switch': False,
        'app_type': AppType.interval,
        'data': {
            'key_list': ['schedule_settings'],
            'config_data': {
                'schedule_settings': {
                    'group_name': '运行设置',
                    'key_list': ['cycle'],
                    'group_member': {
                        'cycle': {
                            'key_name': '运行周期',
                            'key_type': 'float',
                            'key_range': {'min': 0},
                            'key_help': '运行周期，单位秒',
                            'value': 1
                        }
                    }
                }
            }
        }
    }

    def get_admin_host(self):
        return 'localhost'


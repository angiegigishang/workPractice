import json
import copy
from tornado import gen
from tornado.httpclient import AsyncHTTPClient
from mg_app_framework.config import Store, get_handler, get_logger, set_handler, get_store,get_uuid
from mg_app_framework.components import TaskKey
from mg_app_framework.process import start_next_task
from mg_app_framework.client import HttpClient
from mg_app_framework.message import MesCode, IdiMesType
from mg_app_framework.components.websocket_connector import WebSocketClient
from abc import ABCMeta, abstractmethod
from inspect import iscoroutinefunction



class IdiConnectError(Exception):
    def __init__(self):
        Store.get_loop().stop()


class IdiAppType:
    idi_opc = 'idi_opc'
    idi_relational_db = 'idi_relational_db'
    idi_calculation = 'idi_calculation'
    idi_nc = 'idi_nc'
    idi_data_dict_fs = 'idi_data_dict_fs'


class IdiConfigBasic(metaclass=ABCMeta):
    @abstractmethod
    def get_idi_history_connect_dict(self):
        """
            {
                'cfg_server1_url': 'ws: // 192.168.20.186: 8081/configappconn'
            }
        """
        pass

    @abstractmethod
    def get_idi_realtime_connect_dict(self):
        """
            {
                'cfg_server1_url': ''http://192.168.20.186:8081/api/v1/idi/opc/history/tags
            }
        """
        pass

    @abstractmethod
    def get_idi_app_type(self):
        pass

    @abstractmethod
    def get_mongodb_db_handle(self):
        pass

    @abstractmethod
    def idi_msg_process(self, msg):
        pass

    def retry_interval(self):
        return 5


async def idi_send_data(mes_type, data=''):
    logger = get_logger()
    try:
        if mes_type == IdiMesType.idi_tag_data:
            await  _send_history_data(mes_type, data)
            await  _send_realtime_data(data)
        elif mes_type == IdiMesType.idi_interface_cal_info:
            await  _send_data_to_idi_server(mes_type, data)
        else:
            logger.warning('Invalid message type')
    except Exception as e:
        get_logger().exception(e)


async def idi_update_connect():
    store = Store.get_init_task_config(TaskKey.idi)
    await update_websocket_config_process(store.get_idi_history_connect_dict())


async def _send_realtime_data(datas=None):
    if not datas:
        get_logger().warn('parame is none')
        return
    idi_store = Store.get_init_task_config(TaskKey.idi)
    urls = idi_store.get_idi_realtime_connect_dict()
    if not urls or not datas:
        return

    for organization_name, data in datas.items():
        data_tmp = {}
        for dt in data:
            type = dt.get('type')
            if not type:
                continue
            if type not in data_tmp.keys():
                data_tmp.update(
                    {type: {'org':organization_name,'data':[{'code': dt.get('code'), 'value': dt.get('value'), 'timestamp': dt.get('timestamp')}]}})
            else:
                data_tmp[type]['data'].append({'code': dt.get('code'), 'value': dt.get('value'), 'timestamp': dt.get('timestamp')})
        if not data_tmp:
            # dt["type"] == ""或数据条目中没有"type"键值对, 暗示数据不需要实时推送,data_tmp可能为空
            return

        client = HttpClient(AsyncHTTPClient(max_clients=1000, force_instance=True))
        for url in urls.values():
            try:
                response = await client.post(url=url, data=data_tmp, headers={'Content-type': 'json'})
            except Exception as e:
                get_logger().info("send_http_msg: [url %s] failed" % (url))
                get_logger().exception(e)
            else:
                get_logger().debug("send_http_msg: [url %s] [code %s] [info %s]" % (url, response.code, response.info))
        client.close()


async def _send_history_data(mes_type, datas=''):
    # date format
    # {
    #     'organization_kmly': [{
    #         'timestamp': '2018-12-0717: 50: 49',
    #         'code': 'opc_cn_xs',
    #         'value': 0，
    #         'type': 'kpi_lab_from_idi'
    #     },
    #         {
    #             'timestamp': '2018-12-0717: 50: 49',
    #             'code': 'opc_cj_db_1',
    #             'value': 0，
    #             'type': 'kpi_lab_from_idi'
    #         }],
    #     'organization_fsly': [{
    #         'timestamp': '2018-12-0717: 50: 49',
    #         'code': 'opc_cn_xs',
    #         'value': 0，
    #         'type': 'kpi_lab_from_idi'
    #     },
    #         {
    #             'timestamp': '2018-12-0717: 50: 49',
    #             'code': 'opc_cj_db_1',
    #             'value': 0，
    #             'type': 'kpi_lab_from_idi'
    #         }]
    # }

    send_to_idi_server_datas = copy.deepcopy(datas)

    idi_store = Store.get_init_task_config(TaskKey.idi)
    mongodb_handle = idi_store.get_mongodb_db_handle()
    interface_tag_datas_cursor = mongodb_handle.interface_tag_datas.find({}, {"_id": 0})

    for record in interface_tag_datas_cursor :
        for organization_name, tag_datas_temp in record.items():
            if organization_name not in send_to_idi_server_datas.keys():
                send_to_idi_server_datas.update({organization_name:tag_datas_temp})
            else:
                for tag_data_temp in tag_datas_temp:
                    tag_data_temp_if_exist = False
                    for tag_data in send_to_idi_server_datas.get(organization_name):
                        if tag_data.get('timestamp') == tag_data_temp.get('timestamp') and tag_data.get('code') == tag_data_temp.get('code'):
                            tag_data_temp_if_exist = True
                            break
                    if not tag_data_temp_if_exist:
                        send_to_idi_server_datas.get(organization_name).append(tag_data_temp)

    result = await _send_data_to_idi_server(mes_type, send_to_idi_server_datas)

    if result == MesCode.success:
        mongodb_handle.interface_tag_datas.remove()
    else:
        mongodb_handle.interface_tag_datas.insert(datas, check_keys=False)


async def _send_data_to_idi_server(mes_type, data=''):
    idi_store = Store.get_init_task_config(TaskKey.idi)
    instance = get_handler(TaskKey.idi)
    for key in idi_store.get_idi_history_connect_dict().keys():
        handler = instance[key]
        mes = make_websocket_mes(mes_type, data)
        if handler.cli:
            return await handler.send(mes)
        else:
            return MesCode.fail


# app communicate struct
MESSAGE = {
    'app_group': '',
    'app_name': '',
    'type': '',
    'code': MesCode.success,
    'data': '',
    'info': ''
}


def make_websocket_mes(mes_type, data='', info='', code=MesCode.success):
    MESSAGE['type'] = mes_type
    MESSAGE['code'] = code
    MESSAGE['data'] = data
    MESSAGE['info'] = info
    return MESSAGE


async def interface_server_msghandle(msg=None):
    logger = get_logger()
    logger.info(msg)

    try:
        message = json.loads(msg)
        if message['type'] == IdiMesType.idi_init:
            await  _app_init_process(msg)
        elif message['type'] == IdiMesType.idi_mdm_tag_info:
            await  _idi_msg_process(msg)
        else:
            logger.warning('Invalid message type')
    except Exception as e:
        get_logger().exception(e)


async def _app_init_process(msg):
    idi_store = Store.get_init_task_config(TaskKey.idi)
    data = {'app_type': idi_store.get_idi_app_type(), 'app_name': get_store().data.get('app_name'),
            'app_uuid': get_uuid()}
    await _send_data_to_idi_server(IdiMesType.idi_app_info, data)
    await _idi_msg_process(msg)


async def _idi_msg_process(msg):
    idi_store = Store.get_init_task_config(TaskKey.idi)
    fun = idi_store.idi_msg_process
    if iscoroutinefunction(fun):
        await fun(msg)
    else:
        fun(msg)


# connect to the websocket
async def idi_connect(conn_time=None):
    websocket_handler_dict = {}
    try:
        store = Store.get_init_task_config(TaskKey.idi)
        websocket_url_dict = store.get_idi_history_connect_dict()  # get websocket config
        for websocket_name, websocket_url in websocket_url_dict.items():
            __cnt = 0
            while True:
                try:
                    if conn_time and __cnt == int(conn_time):
                        get_logger().error('idi connect error,connect more than ' + str(conn_time) + ' times')
                        raise IdiConnectError
                    websocket_handler = WebSocketClient(websocket_url,
                                                        interface_server_msghandle)  # init websocket client
                    await websocket_handler.get_client()  # connect websocket
                    websocket_handler_dict[websocket_name] = websocket_handler
                    get_logger().info('%s:%s idi websocket connected successfully' % (websocket_name, websocket_url))
                    break
                except Exception:
                    __cnt += 1
                    get_logger().exception(
                        '%s:%s idi websocket connecting retry number: %d ' % (websocket_name, websocket_url, __cnt))
                    store = Store.get_init_task_config(TaskKey.idi)
                    await gen.sleep(store.retry_interval())
    except Exception as e:
        get_logger().exception('idi websocket connected fail:%s' % str(e))
    else:
        set_handler(TaskKey.idi, websocket_handler_dict)
        loop = Store.get_loop()
        loop.spawn_callback(websocket_process)
        start_next_task(TaskKey.idi)


async def update_websocket_config_process(update_dict):
    """
    change the websocket connector whose websocket_name in update_dict
    ..example:
        update_dict = {
        "websocket_url_first":"ws://127.0.0.1/websocket_url",
        "websocket_url_second":"ws://127.0.0.1/websocket_url_second",
        }
        the key of update_dict should in your websocket_url_dict config,
        and the value is the new websocket_url you want to change connect to
    """
    try:
        websocket_handler_dict = get_handler(TaskKey.idi)
        for websocket_name, websocket_url in update_dict.items():
            if websocket_name in websocket_handler_dict.keys():
                if websocket_url != websocket_handler_dict[websocket_name].url:
                    websocket_handler_dict[websocket_name].set_url(websocket_url)
    except Exception as e:
        get_logger().exception("update websocket connector error : %s" % str(e))


async def websocket_process():
    try:
        websocket_handler_dict = get_handler(TaskKey.idi)
        for websocket_name, websocket_handler in websocket_handler_dict.items():
            websocket_handler.receive_cycle()
    except Exception as e:
        logger = get_logger()
        logger.exception("websocket receive_cycle error:%s" % str(e))

from abc import ABCMeta, abstractmethod
from tornado import gen

from mg_app_framework.config import Store, set_handler, get_logger
from mg_app_framework.components import TaskKey
from mg_app_framework.process import start_next_task


class OpcConnectError(Exception):
    def __init__(self):
        Store.get_loop().stop()


class OpcdaConfigBasic(metaclass=ABCMeta):
    @abstractmethod
    def get_opc_host(self):
        pass

    @abstractmethod
    def get_opc_domain(self):
        pass

    @abstractmethod
    def get_opc_username(self):
        pass

    @abstractmethod
    def get_opc_password(self):
        pass

    @abstractmethod
    def get_opc_clsid(self):
        pass

    def retry_interval(self):
        return 5


class OpcdaConnector:
    def __init__(self):
        from jnius import autoclass

        self.OpcClient = autoclass('com.realtech.OpcClient')
        self.opc = self.OpcClient()

        store = Store.get_init_task_config(TaskKey.opc)
        opc_host = store.get_opc_host()
        opc_domain = store.get_opc_domain()
        opc_username = store.get_opc_username()
        opc_password = store.get_opc_password()
        opc_clsid = store.get_opc_clsid()
        self.opc.connect(opc_host, opc_domain, opc_username, opc_password, opc_clsid)

        for key in Store.get_opc_r_group():
            self.add_r_group(key)
        for key in Store.get_opc_w_group():
            self.add_w_group(key)

    def disconnect(self):
        self.opc.disConnect()

    def add_r_group(self, key):
        self.opc.addReadGroup(key)

    def add_w_group(self, key):
        self.opc.addWriteGroup(key)

    def read(self, keys):
        data = {}
        for key in keys:
            value = self.opc.readItem(key)
            data[key] = float(value)

        return data

    def write(self, data):
        for key, value in data.items():
            self.opc.writeItem(key, str(value))


# connect to opc_server
async def opcda_connect(re_conn=True, conn_time=None):
    __cnt = 0
    while True:
        try:
            if conn_time and __cnt == int(conn_time):
                get_logger().error('Opcda connect error,connect more than ' + str(conn_time) + ' times')
                raise OpcConnectError
            connector = OpcdaConnector()
            get_logger().info('opc connected successfully')
            set_handler(TaskKey.opc, connector)
            if not re_conn:
                start_next_task(TaskKey.opc)
                break
            else:
                return connector
        except Exception:
            __cnt += 1
            get_logger().exception('opc connecting retry number: ' + str(__cnt))
            store = Store.get_init_task_config(TaskKey.opc)
            await gen.sleep(store.retry_interval())


class OpcuaConfigBasic(metaclass=ABCMeta):
    @abstractmethod
    def get_opcua_ip(self):
        pass

    @abstractmethod
    def get_opcua_port(self):
        pass

    @abstractmethod
    def get_opcua_security_mode(self):
        pass

    @abstractmethod
    def get_opcua_security_policy(self):
        pass

    @abstractmethod
    def get_opcua_certificate_path(self):
        pass

    @abstractmethod
    def get_opcua_private_key_path(self):
        pass

    def retry_interval(self):
        return 5


class OpcuaConnector(object):
    def __init__(self):
        store = Store.get_init_task_config(TaskKey.opcua)
        self._connected = False
        self.security_mode = store.get_opcua_security_mode()
        self.security_policy = store.get_opcua_security_policy()
        self.certificate_path = store.get_opcua_certificate_path
        self.private_key_path = store.get_opcua_private_key_path()
        self.uri = 'opc.tcp://{}:{}'.format(store.get_opcua_ip(), store.get_opcua_port())
        self._connect()

    def _connect(self):
        from opcua import Client, ua, crypto
        self.client = Client(self.uri)
        if self.security_mode is not None and self.security_policy is not None:
            self.client.set_security(
                getattr(crypto.security_policies, 'SecurityPolicy' + self.security_policy),
                self.certificate_path,
                self.private_key_path,
                mode=getattr(ua.MessageSecurityMode, self.security_mode)
            )
        self.client.connect()
        self._connected = True

    def disconnect(self):
        if self._connected:
            get_logger().info("Disconnecting from server")
            self.client.disconnect()
            self.client = None
            self._connected = False

    def read(self, keys):
        data = {}
        for key in keys:
            node = self.client.get_node(key)
            name = node.get_display_name().to_string()
            description = node.get_description().to_string()
            data_type = node.get_data_type_as_variant_type()
            value = node.get_value()
            acs = node.get_access_level()
            access = [ac.value for ac in acs]
            data[key] = {
                'name': name,
                'description': description,
                'type': data_type,
                'value': value,
                'access': access
            }
        return data

    def write(self, key, value):
        node = self.client.get_node(key)
        # get the variant_type of this node
        target_type = node.get_data_type_as_variant_type()
        try:
            # try to convert value to the target_type automatically
            node.set_value(value=value, varianttype=target_type)
        except Exception as e:
            # raise exception if the value can't converted to target_type
            get_logger().error(e)
            raise e


async def opcua_connect(re_conn=True, conn_time=None):
    __cnt = 0
    while True:
        try:
            if conn_time and __cnt == int(conn_time):
                get_logger().error('Opcua connect error,connect more than ' + str(conn_time) + ' times')
                raise OpcConnectError
            connector = OpcuaConnector()
            get_logger().info('opc connected successfully')
            set_handler(TaskKey.opcua, connector)
            if not re_conn:
                start_next_task(TaskKey.opcua)
                break
            else:
                return connector
        except Exception:
            __cnt += 1
            get_logger().exception('opc connecting retry number: ' + str(__cnt))
            store = Store.get_init_task_config(TaskKey.opcua)
            await gen.sleep(store.retry_interval())

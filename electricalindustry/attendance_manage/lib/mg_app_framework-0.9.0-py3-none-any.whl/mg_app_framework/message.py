import json

from mg_app_framework.config import Store, get_context, get_logger, get_handler
from mg_app_framework.components import TaskKey


class MesType:
    init_config = 'init_config'
    update_config = 'update_config'
    alarm = 'alarm'
    ha = 'ha'


class AlarmLevel:
    positive = 'positive'
    warning = 'warning'
    negative = 'negative'


class MesCode:
    success = 'success'
    fail = 'fail'
    login = 'login'


class HaMesType:
    init_connect = 'init_connect'
    update_data = 'update_data'
    change_to_master = 'change_to_master'
    change_to_follower = 'change_to_follower'
    connection_close = 'connection_close'
    ha_auto_update = 'ha_auto_update'


class IdiMesType:
    idi_init = 'app_init'
    idi_mdm_tag_info = 'idi_mdm_tag_info'
    idi_interface_cal_info = 'idi_interface_cal_info'
    idi_tag_data = 'idi_tag_data'
    idi_app_info = 'app_info'


def make_mes(mes_type, data='', info='', code=MesCode.success):
    message = {
        'app_group': Store.get_app_group(),
        'app_name': Store.get_app_name(),
        'type': mes_type,  # MesType.init_config or MesType.update_config or MesType.alarm or MesType.ha
        'code': code,
        'data': data,
        'info': info
    }
    return message


async def send_mes(handler, mes_type, data='', info='', code=MesCode.success):
    try:
        message = make_mes(mes_type, data, info, code)
        await handler.write_message(json.dumps(message))
    except Exception as e:
        get_logger().error('sending websocket message failed')
        raise e


def send_mes_sync(handler, mes_type, data='', info='', code=MesCode.success):
    try:
        message = make_mes(mes_type, data, info, code)
        handler.write_message(json.dumps(message))
    except Exception as e:
        get_logger().error('sending websocket message failed')
        raise e


# send message
async def send_ha_mes(mes_type, data=''):
    ha_handler = Store.get_ha_handler()
    ha_connection = get_context('ha_connection')
    if ha_handler is not None:
        await send_mes(ha_handler, mes_type, json.dumps(data))
    elif ha_connection is not None:
        await send_mes(ha_connection, mes_type, json.dumps(data))


def send_ha_mes_sync(mes_type, data=''):
    ha_handler = Store.get_ha_handler()
    ha_connection = get_context('ha_connection')
    if ha_handler is not None:
        send_mes_sync(ha_handler, mes_type, json.dumps(data))
    elif ha_connection is not None:
        send_mes_sync(ha_connection, mes_type, json.dumps(data))


def send_alarm(info='', level=AlarmLevel.negative):
    try:
        admin_handler = get_handler(TaskKey.admin)
        message = {
            'app_group': Store.get_app_group(),
            'app_name': Store.get_app_name(),
            'type': MesType.alarm,
            'code': MesCode.success,
            'level': level,
            'info': info
        }
        admin_handler.write_message(json.dumps(message))
    except Exception as e:
        get_logger().error('sending alarm message failed')
        get_logger().error(str(e))
